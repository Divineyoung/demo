Upload this folder to Vercel or Netlify. Entry file: index.html
